print("""
    Very
    nice
    e

""")